using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Movement : MonoBehaviour
{
    [SerializeField]
    float speed = 1f;
    
    float x, y;
    MP_CameraControl cam;
    Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        cam = FindObjectOfType<MP_CameraControl>();
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxisRaw("Horizontal");
        y = Input.GetAxisRaw("Vertical");
    }

    private void FixedUpdate()
    {
        Vector3 forward = Vector3.Scale(cam.GetDir().forward, new Vector3(1, 0, 1)).normalized;
        Vector3 movement = (y * forward + x * cam.GetDir().right).normalized;

        rb.MovePosition(transform.position + movement * speed);
    }
    public void SetSpeed(float newSpeed)
    {
        speed = newSpeed;
    }
    public float GetSpeed()
    {
        return speed;
    }
}
