using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MP_SwapGravity : MonoBehaviour
{

    bool isAdvanced = true;
    GameObject basicGun;
    MP_AdvancedGravity advancedGun;
    RawImage ret;
    Text controls;

    // Start is called before the first frame update
    void Start()
    {
        basicGun = FindObjectOfType<MP_BasicGravity>().gameObject;
        advancedGun = GetComponent<MP_AdvancedGravity>();
        ret = FindObjectOfType<MP_Reticle>().GetComponent<RawImage>();
        controls = FindObjectOfType<MP_Controls>().GetComponent<Text>();
        UpdateGuns();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.G))
        {
            isAdvanced = !isAdvanced;
            UpdateGuns();
        }
    }

    void UpdateGuns()
    {
        if (isAdvanced)
        {
            controls.text = "Move - WASD \n Select / Deselect Object - Left Click \n Toggle Rotate Object -Right Click \n Extend / Retract Object - Mouse Wheel \n Switch to Basic Gravitygun - G";
            basicGun.SetActive(false);
            ret.enabled = true;
            advancedGun.statemachine.ChangeState(MP_Aiming.Instance);
            advancedGun.SetBool(0, true);
            advancedGun.enabled = true;
        }
        else
        {
            controls.text = "Move - WASD \n Grab Object in Sphere - Left Click \n Switch to Advanced Gravitygun - G";
            ret.enabled = false;
            advancedGun.statemachine.ChangeState(MP_Aiming.Instance);
            advancedGun.enabled = false;
            basicGun.SetActive(true);
        }
    }
}
