using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_CameraControl : MonoBehaviour
{
    [SerializeField]
    float mouseSens;

    GameObject dir;
    Vector3 offset;
    GameObject player;
    float rotX, rotY;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_Movement>().gameObject;
        transform.position = new Vector3(player.transform.position.x, player.transform.position.y + 4, player.transform.position.z - 8);
        offset = player.transform.position - transform.position;
        transform.rotation = Quaternion.Euler(new Vector3(30, 0, 0));

        dir = new GameObject("dirObj");
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 targetPos = new Vector3(player.transform.position.x, player.transform.position.y + 2, player.transform.position.z);

        transform.rotation = (transform.rotation * Quaternion.Euler(new Vector3(0, Input.GetAxis("Mouse X") * mouseSens, 0)));
        rotX += Input.GetAxis("Mouse Y") * mouseSens;
        rotX = Mathf.Clamp(rotX, -40f, 45f);

        rotY = transform.eulerAngles.y;
        Quaternion rotation = Quaternion.Euler(-rotX, rotY, 0);

        transform.position = targetPos - (rotation * offset);
        transform.LookAt(targetPos);

        dir.transform.rotation = Quaternion.Euler(0, transform.eulerAngles.y, 0);
    }

    public Transform GetDir()
    {
        return dir.transform;
    }
    public float GetSens()
    {
        return mouseSens;
    }
    public void SetSens(float newFloat)
    {
        mouseSens = newFloat;
    }
}
