using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StatesMac;

public class MP_Rotate : State<MP_AdvancedGravity>
{
    private static MP_Rotate _instance;

    private MP_Rotate()
    {
        if (_instance != null)
        {
            return;
        }

        _instance = this;
    }

    public static MP_Rotate Instance
    {
        get
        {
            if (_instance == null)
            {
                new MP_Rotate();
            }

            return _instance;
        }
    }

    public override void EnterState(MP_AdvancedGravity _owner)
    {
        Debug.Log("Enter Rotate");
        _owner.GetCam().gameObject.GetComponent<MP_CameraControl>().SetSens(0);
        _owner.SetFloat(5, Time.time);
        _owner.SetBool(9, false);
        _owner.SetFloat(6, _owner.GetRB().angularDrag);

        if(_owner.GetTarget().transform.localScale.x > _owner.GetTarget().transform.localScale.y && _owner.GetTarget().transform.localScale.x > _owner.GetTarget().transform.localScale.z)
        {
            _owner.SetFloat(7, _owner.GetFloat(8) * _owner.GetTarget().transform.localScale.x);
        }
        else if(_owner.GetTarget().transform.localScale.y > _owner.GetTarget().transform.localScale.x && _owner.GetTarget().transform.localScale.y > _owner.GetTarget().transform.localScale.z)
        {
            _owner.SetFloat(7, _owner.GetFloat(8) * _owner.GetTarget().transform.localScale.y);
        }
        else if(_owner.GetTarget().transform.localScale.z > _owner.GetTarget().transform.localScale.x && _owner.GetTarget().transform.localScale.z > _owner.GetTarget().transform.localScale.y)
        {
            _owner.SetFloat(7, _owner.GetFloat(8) * _owner.GetTarget().transform.localScale.z);
        }
        else
        {
            _owner.SetFloat(7, _owner.GetFloat(8) * ((_owner.GetTarget().transform.localScale.x + _owner.GetTarget().transform.localScale.y + _owner.GetTarget().transform.localScale.z) / 3));
        }
    }

    public override void ExitState(MP_AdvancedGravity _owner)
    {
        _owner.GetCam().gameObject.GetComponent<MP_CameraControl>().SetSens(1);
        _owner.GetRB().angularDrag = _owner.GetFloat(6);
        _owner.SetFloat(2, Vector3.Distance(_owner.GetCam().transform.position, _owner.GetTarget().transform.position));
        _owner.SetFloat(2, _owner.GetFloat(2) - 0.75f);
        _owner.SetVector(1, _owner.GetCam().ViewportPointToRay(Vector3.one * 0.5f).GetPoint(_owner.GetFloat(2)));
        _owner.SetFloat(4, Time.time);
        Debug.Log("Exit Rotate");
    }

    public override void UpdateState(MP_AdvancedGravity _owner)
    {
        if(Input.GetMouseButtonDown(1) && Time.time - _owner.GetFloat(5) > 0.2f)
        {
            _owner.statemachine.ChangeState(MP_GravityGun.Instance);
        }

        if (_owner.GetRB().velocity.magnitude != 0)
            _owner.SetBool(9, true);

        if (_owner.GetBool(6) && !_owner.GetBool(9))
        {
            _owner.SetFloat(2, _owner.GetFloat(2) + 0.1f);
        }

        if (Vector3.Distance(_owner.GetTarget().transform.position, _owner.GetVector(1)) > 1.7f && !_owner.GetBool(9))
        {
            _owner.GetRB().angularVelocity = Vector3.zero;
            _owner.SetVector(1, _owner.GetCam().ViewportPointToRay(Vector3.one * 0.5f).GetPoint(_owner.GetFloat(2)));
            Vector3 centerDest = _owner.GetVector(1) - _owner.GetRB().transform.TransformVector(_owner.GetVector(0));
            Vector3 toDest = centerDest - _owner.GetRB().transform.position;

            Vector3 force = toDest * 30f;
            _owner.GetRB().AddForce(force, ForceMode.Force);
        }
        else
        {
            _owner.SetBool(9, true);
        }

        if(Input.GetAxis("Mouse Y") != 0 || Input.GetAxis("Mouse X") != 0)
        {
            _owner.GetRB().AddTorque((Input.GetAxis("Mouse Y") * _owner.GetFloat(7) + 1) * _owner.GetCam().transform.right, ForceMode.Force);
            _owner.GetRB().AddTorque((Input.GetAxis("Mouse X") * -_owner.GetFloat(7)) * _owner.GetCam().transform.up, ForceMode.Force);
            _owner.GetRB().angularDrag = 5;
        }
        else
        {
            _owner.GetRB().angularVelocity = Vector3.zero;
        }
        //_owner.statemachine.ChangeState(TargetState.Instance);
    }
}
