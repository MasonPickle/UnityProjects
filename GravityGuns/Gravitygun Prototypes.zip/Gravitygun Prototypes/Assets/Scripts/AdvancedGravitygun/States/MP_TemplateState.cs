using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StatesMac;

public class MP_TemplateState : State<MP_AdvancedGravity>
{
    private static MP_TemplateState _instance;

    private MP_TemplateState()
    {
        if (_instance != null)
        {
            return;
        }

        _instance = this;
    }

    public static MP_TemplateState Instance
    {
        get
        {
            if (_instance == null)
            {
                new MP_TemplateState();
            }

            return _instance;
        }
    }

    public override void EnterState(MP_AdvancedGravity _owner)
    {

    }

    public override void ExitState(MP_AdvancedGravity _owner)
    {

    }

    public override void UpdateState(MP_AdvancedGravity _owner)
    {
        //_owner.statemachine.ChangeState(TargetState.Instance);
    }
}
