using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StatesMac;

public class MP_Aiming : State<MP_AdvancedGravity>
{
    private static MP_Aiming _instance;

    private MP_Aiming()
    {
        if (_instance != null)
        {
            return;
        }

        _instance = this;
    }

    public static MP_Aiming Instance
    {
        get
        {
            if (_instance == null)
            {
                new MP_Aiming();
            }

            return _instance;
        }
    }

    public override void EnterState(MP_AdvancedGravity _owner)
    {
        Debug.Log("Enter Aiming");
    }

    public override void ExitState(MP_AdvancedGravity _owner)
    {
        _owner.SetBool(0, false);
        Debug.Log("Exit Aiming");
    }

    public override void UpdateState(MP_AdvancedGravity _owner)
    {
        if(Input.GetMouseButtonUp(0) && !_owner.GetBool(0))
        {
            _owner.SetBool(0, true);
        }
        if(Input.GetMouseButton(0) && _owner.GetBool(0) && _owner.GetBool(1))
        {
            _owner.SetTarget(_owner.GetHit(0).transform.gameObject);
            _owner.SetVector(0, _owner.GetTarget().transform.InverseTransformVector(_owner.GetHit(0).point - _owner.GetHit(0).transform.position));
            _owner.SetFloat(2, Vector3.Distance(_owner.GetCam().transform.position, _owner.GetHit(0).point));
            _owner.SetFloat(2, _owner.GetFloat(2) - 0.3f);
            _owner.statemachine.ChangeState(MP_GravityGun.Instance);
        }
        //_owner.statemachine.ChangeState(TargetState.Instance);
    }
}
