using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StatesMac;

public class MP_GravityGun : State<MP_AdvancedGravity>
{
    private static MP_GravityGun _instance;

    private MP_GravityGun()
    {
        if (_instance != null)
        {
            return;
        }

        _instance = this;
    }

    public static MP_GravityGun Instance
    {
        get
        {
            if (_instance == null)
            {
                new MP_GravityGun();
            }

            return _instance;
        }
    }

    public override void EnterState(MP_AdvancedGravity _owner)
    {
        Debug.Log("Enter Moving");
        if (!_owner.GetBool(2))
        {
            _owner.GetTarget().GetComponent<MeshRenderer>().material.EnableKeyword("_EMISSION");
            _owner.SetRB();
            _owner.GetRB().useGravity = false;
            _owner.SetFloat(3, _owner.GetRB().drag);
            _owner.GetRB().velocity = Vector3.zero;

            _owner.GetCam().gameObject.GetComponent<MP_CameraControl>().SetSens(1);
            _owner.PlayerStop();

            _owner.SetFloat(4, Time.time);
        }
        else
        {
            _owner.SetBool(2, false);
        }
    }

    public override void ExitState(MP_AdvancedGravity _owner)
    {
        if (!_owner.GetBool(3))
        {
            _owner.GetTarget().GetComponent<MeshRenderer>().material.DisableKeyword("_EMISSION");
            _owner.GetRB().useGravity = true;
            _owner.GetRB().drag = _owner.GetFloat(3);
            _owner.NoRB();

            _owner.SetTarget(null);

            _owner.GetCam().gameObject.GetComponent<MP_CameraControl>().SetSens(_owner.GetFloat(1));
            _owner.PlayerMove();
            if (_owner.GetBool(7))
            {
                _owner.SetBool(0, true);
                _owner.SetBool(7, false);
                _owner.SetBool(6, false);
                _owner.SetBool(8, false);
            }
            else
            {
                _owner.SetBool(0, false);
            }
            
        }
        else
        {
            _owner.SetBool(3, false);
        }
        Debug.Log("Exit Moving");
    }

    public override void UpdateState(MP_AdvancedGravity _owner)
    {
        if(Input.GetAxis("Mouse ScrollWheel") != 0f && _owner.GetFloat(2) <= _owner.GetFloat(0))
        {
            if (_owner.GetBool(4))
            {
                _owner.SetFloat(2, _owner.GetFloat(2) + 1);
            }
            else
            {
                _owner.SetFloat(2, _owner.GetFloat(2) + Input.GetAxis("Mouse ScrollWheel") * 5);
            }
        }

        _owner.GetRB().angularVelocity = Vector3.zero;
        _owner.SetVector(1, _owner.GetCam().ViewportPointToRay(Vector3.one * 0.5f).GetPoint(_owner.GetFloat(2)));
        Vector3 centerDest = _owner.GetVector(1) - _owner.GetRB().transform.TransformVector(_owner.GetVector(0));
        Vector3 toDest = centerDest - _owner.GetRB().transform.position;
        Vector3 force = toDest * 30f;
        if (!_owner.GetBool(5) && _owner.GetRB().velocity.magnitude < 30)
            _owner.GetRB().AddForce(force, ForceMode.Force);

        float dampenThreshold = -0.5f;
        float dot = Vector3.Dot(_owner.GetRB().velocity.normalized, toDest.normalized);

        if (dot < dampenThreshold)
        {
            _owner.GetRB().velocity.Set(0, 0, 0);
            _owner.GetRB().drag = 10f;
        }

        if (Input.GetMouseButtonUp(0) && !_owner.GetBool(0))
        {
            _owner.SetBool(0, true);
        }
        if (Input.GetMouseButton(0) && _owner.GetBool(0))
        {
            _owner.statemachine.ChangeState(MP_Aiming.Instance);
        }
        if (!Input.GetMouseButton(0) && Input.GetMouseButtonDown(1))
        {
            _owner.SetBool(2, true);
            _owner.SetBool(3, true);
            _owner.statemachine.ChangeState(MP_Rotate.Instance);
        }

        _owner.SetBool(7, false);
        if (_owner.GetBool(6))
        {
            _owner.SetFloat(4, Time.time);
        }
        else if (Time.time - _owner.GetFloat(4) > 1)
        {
            Debug.Log("too far");
            _owner.SetBool(7, true);
        }
        if (_owner.GetBool(8))
        {
            Debug.Log("no sight");
            _owner.SetBool(7, true);
        }
        if (_owner.GetBool(7))
        {
            Debug.Log("exit through 7");
            _owner.statemachine.ChangeState(MP_Aiming.Instance);
        }
        //_owner.statemachine.ChangeState(TargetState.Instance);
    }
}
