using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using StatesMac;
using UnityEngine.UI;

public class MP_AdvancedGravity : MonoBehaviour
{

    RaycastHit grabHit, scrollHit, farHit, seeHit;
    Vector3 holdPoint, hitOffset, pointOne, pointTwo;
    [SerializeField]
    bool canExit = false, tooClose = false, skipExit = false, skipEnter = false, canGrab = false, canScroll = false, switchAim = false, tooFar = false, canSee = false, centered = false;
    GameObject target;
    Camera cam;
    Rigidbody rb;
    float initialDrag, initialRotDrag, grabDistance = 0, timer, inputTimer, rotateX, dist = 30, rotSpeed = 10, curSpeed, curRot, tempRot;
    RigidbodyInterpolation iSetting;
    CapsuleCollider col;

    public MP_StateMachine<MP_AdvancedGravity> statemachine { get; set; }

    private void Awake()
    {
        curSpeed = GetComponent<MP_Movement>().GetSpeed();
        cam = FindObjectOfType<MP_CameraControl>().gameObject.GetComponent<Camera>();
        curRot = cam.gameObject.GetComponent<MP_CameraControl>().GetSens();

        statemachine = new MP_StateMachine<MP_AdvancedGravity>(this);
        statemachine.ChangeState(MP_Aiming.Instance);
    }
    // Start is called before the first frame update
    void Start()
    {
        col = GetComponent<CapsuleCollider>();
    }

    // Update is called once per frame
    void Update()
    {
        statemachine.Update();

        if (Vector3.Distance(transform.position, holdPoint) < 1)
        {
            tooClose = true;
        }
        else
        {
            tooClose = false;
        }
    }

    private void FixedUpdate()
    {
        if(statemachine.curState == MP_Aiming.Instance)
            canGrab = Physics.Raycast(cam.transform.position + (cam.transform.forward * 8), cam.transform.forward, out grabHit, dist) && grabHit.transform.gameObject.GetComponent<MP_Grabbable>();

        pointOne = transform.position + new Vector3(0, 0.5f, 0);
        pointTwo = transform.position + new Vector3(0, -0.5f, 0);

        if(statemachine.curState == MP_Rotate.Instance)
            canScroll = Physics.CapsuleCast(pointOne, pointTwo, col.radius * transform.localEulerAngles.x, target.transform.position - transform.position, out scrollHit, 2) && scrollHit.transform.gameObject == target;

        if(statemachine.curState == MP_GravityGun.Instance)
        {
            tooFar = Physics.Raycast(holdPoint, target.transform.position - holdPoint, out farHit, 1) && farHit.transform.gameObject == target;

            canSee = Physics.Raycast(target.transform.position, new Vector3(transform.position.x, transform.position.y + 2, transform.position.z) - target.transform.position, out seeHit) && seeHit.transform.gameObject != cam.gameObject;
            Debug.DrawRay(target.transform.position, new Vector3(transform.position.x, transform.position.y + 2, transform.position.z) - target.transform.position);
        }
        
    }
    public Camera GetCam()
    {
        return cam;
    }
    public void SetRB()
    {
        rb = target.GetComponent<Rigidbody>();
        iSetting = rb.interpolation;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
    }
    public void NoRB()
    {
        rb.interpolation = iSetting;
        rb = null;
    }
    public Rigidbody GetRB()
    {
        return rb;
    }
    public void PlayerStop()
    {
        GetComponent<MP_Movement>().SetSpeed(0);
        GetComponent<Rigidbody>().velocity = Vector3.zero;
    }
    public void PlayerMove()
    {
        GetComponent<MP_Movement>().SetSpeed(curSpeed);
    }
    public void SetTarget(GameObject newTarget)
    {
        target = newTarget;
    }
    public GameObject GetTarget()
    {
        return target;
    }
    public void SetTarget()
    {
        target = grabHit.transform.gameObject;
        hitOffset = target.transform.InverseTransformVector(grabHit.point - grabHit.transform.position);
        grabDistance = Vector3.Distance(cam.transform.position, grabHit.point);
        grabDistance -= 0.3f;
    }

    public float GetFloat(int index)
    {
        switch (index)
        {
            case 0:
                return dist;
            case 1:
                return curRot;
            case 2:
                return grabDistance;
            case 3:
                return initialDrag;
            case 4:
                return timer;
            case 5:
                return inputTimer;
            case 6:
                return initialRotDrag;
            case 7:
                return tempRot;
            case 8:
                return rotSpeed;
        }
        return 0;
    }
    public bool GetBool(int index)
    {
        switch (index)
        {
            case 0:
                return canExit;
            case 1:
                return canGrab;
            case 2:
                return skipEnter;
            case 3:
                return skipExit;
            case 4:
                return canScroll;
            case 5:
                return tooClose;
            case 6:
                return tooFar;
            case 7:
                return switchAim;
            case 8:
                return canSee;
            case 9:
                return centered;
        }
        return false;
    }
    public Vector3 GetVector(int index)
    {
        switch (index)
        {
            case 0:
                return hitOffset;
            case 1:
                return holdPoint;
        }
        return new Vector3(0, 0, 0);
    }
    public RaycastHit GetHit(int index)
    {
        switch (index)
        {
            case 0:
                return grabHit;
            case 1:
                return scrollHit;
            case 2:
                return farHit;
            case 3:
                return seeHit;
        }
        return grabHit;
    }
    public void SetBool(int index, bool trueFalse)
    {
        switch (index)
        {
            case 0:
                canExit = trueFalse;
                break;
            case 1:
                canGrab = trueFalse;
                break;
            case 2:
                skipEnter = trueFalse;
                break;
            case 3:
                skipExit = trueFalse;
                break;
            case 4:
                canScroll = trueFalse;
                break;
            case 5:
                tooClose = trueFalse;
                break;
            case 6:
                tooFar = trueFalse;
                break;
            case 7:
                switchAim = trueFalse;
                break;
            case 8:
                canSee = trueFalse;
                break;
            case 9:
                centered = trueFalse;
                break;
        }
    }
    public void SetVector(int index, Vector3 newVector)
    {
        switch (index)
        {
            case 0:
                hitOffset = newVector;
                break;
            case 1:
                holdPoint = newVector;
                break;
        }
    }
    public void SetFloat(int index, float newFloat)
    {
        switch (index)
        {
            case 0:
                dist = newFloat;
                break;
            case 1:
                curRot = newFloat;
                break;
            case 2:
                grabDistance = newFloat;
                break;
            case 3:
                initialDrag = newFloat;
                break;
            case 4:
                timer = newFloat;
                break;
            case 5:
                inputTimer = newFloat;
                break;
            case 6:
                initialRotDrag = newFloat;
                break;
            case 7:
                tempRot = newFloat;
                break;
            case 8:
                rotSpeed = newFloat;
                break;
        }
    }
}
