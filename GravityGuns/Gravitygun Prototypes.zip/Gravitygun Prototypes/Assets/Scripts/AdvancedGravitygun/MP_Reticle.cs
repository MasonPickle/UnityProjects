using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MP_Reticle : MonoBehaviour
{
    MP_AdvancedGravity AGG;
    RawImage ret;
    // Start is called before the first frame update
    void Start()
    {
        AGG = FindObjectOfType<MP_AdvancedGravity>();
        ret = GetComponent<RawImage>();
    }

    // Update is called once per frame
    void Update()
    {
        if (AGG.GetBool(1) && AGG.statemachine.curState == MP_Aiming.Instance)
        {
            ret.color = Color.grey;
        }
        else if (AGG.statemachine.curState == MP_GravityGun.Instance || AGG.statemachine.curState == MP_Rotate.Instance)
        {
            ret.color = Color.white;
        }
        else
        {
            ret.color = Color.black;
        }
    }
}
