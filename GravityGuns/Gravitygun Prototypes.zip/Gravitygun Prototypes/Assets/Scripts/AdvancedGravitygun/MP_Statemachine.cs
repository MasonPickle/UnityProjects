using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace StatesMac
{
    public class MP_StateMachine<T>
    {
        public State<T> curState { get; private set; }
        public T Owner;

        public MP_StateMachine(T _o)
        {
            Owner = _o;
            curState = null;
        }

        public void ChangeState(State<T> _newState)
        {
            if (curState != null)
                curState.ExitState(Owner);
            curState = _newState;
            curState.EnterState(Owner);
        }

        public void Update()
        {
            if (curState != null)
                curState.UpdateState(Owner);
        }
    }

    public abstract class State<T>
    {
        public abstract void EnterState(T _owner);
        public abstract void ExitState(T _owner);
        public abstract void UpdateState(T _owner);
    }
}
