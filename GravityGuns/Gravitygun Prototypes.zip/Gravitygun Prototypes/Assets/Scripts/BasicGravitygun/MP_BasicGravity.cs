using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_BasicGravity : MonoBehaviour
{
    GameObject heldObj;
    Rigidbody rb;
    float startDrag;

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonUp(0) && heldObj != null)
        {
            rb.drag = startDrag;
            heldObj.transform.parent = null;
            heldObj = null;
        }
        if(heldObj != null)
        {
            if(Vector3.Distance(transform.position, heldObj.transform.position) > 3)
            {
                rb.drag = startDrag;
                heldObj.transform.parent = null;
                heldObj = null;
            }
        }
    }

    private void FixedUpdate()
    {
        if(heldObj != null)
        {
            heldObj.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
            Vector3 toDest = transform.position - heldObj.transform.position;
            Vector3 force = toDest * 200f;
            heldObj.GetComponent<Rigidbody>().AddForce(force, ForceMode.Force);
            float dampenThreshold = -0.5f;
            float dot = Vector3.Dot(rb.velocity.normalized, toDest.normalized);

            if(dot < dampenThreshold)
            {
                rb.velocity.Set(0, 0, 0);
                rb.drag = 10f;
            }
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.gameObject.GetComponent<MP_Grabbable>())   
        {
            if(Input.GetMouseButton(0) && heldObj == null)
            {
                heldObj = other.gameObject;
                rb = heldObj.GetComponent<Rigidbody>();
                startDrag = rb.drag;
                heldObj.transform.position = transform.position;
                rb.velocity.Set(0, 0, 0);
                rb.drag = 10f;
            }           
        }
    }
}
