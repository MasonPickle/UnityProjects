using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using System.Diagnostics;

public class MP_GameIcon : MonoBehaviour
{
    string filePath, imagePath, fileName;
    Texture fileImage;
    int gameNumber = 0;
    
    RawImage icon;
    Text gameName;

    // Start is called before the first frame update
    void Start()
    {
        icon = GetComponent<RawImage>();
        gameName = GetComponentInChildren<Text>();
    }
    public void SetPath(string path)
    {
        filePath = path;
    }
    public void SetImage(string path)
    {
        //set if null
        if (icon == null)
            icon = GetComponent<RawImage>();
        imagePath = path;
        FileStream fs = new FileStream(path, FileMode.Open);
        byte[] thebytes = new byte[fs.Length];
        int temper = (int)fs.Length;
        fs.Read(thebytes, 0, temper);

        Texture2D texture = new Texture2D(352, 288, TextureFormat.ARGB32, false);
        texture.LoadImage(thebytes);

        fileImage = texture;
        icon.texture = fileImage;
    }
    public void SetName(string path)
    {
        //set if null
        if (gameName == null)
            gameName = GetComponentInChildren<Text>();
        fileName = path;
        gameName.text = fileName;
    }

    public void SaveData(int gameIndex)
    {
        gameNumber = gameIndex;
        List<string> iconData = new List<string>();
        iconData.Add(filePath);
        iconData.Add(imagePath);
        iconData.Add(fileName);
        string s = string.Join(",", iconData.ToArray());
        UnityEngine.Debug.Log(s);
        PlayerPrefs.SetString("game:" + gameIndex, s);
    }
    public void LoadData(int gameIndex)
    {
        gameNumber = gameIndex;
        string loadedData = PlayerPrefs.GetString("game:" + gameIndex);
        UnityEngine.Debug.Log(loadedData);
        string[] splitData = loadedData.Split(',');

        SetPath(splitData[0]);
        SetImage(splitData[1]);
        SetName(splitData[2]);
    }

    public void RunGame()
    {
        Process game = new Process();
        game.StartInfo.FileName = filePath;
        game.Start();
    }

    public void DeleteThis()
    {
        FindObjectOfType<MP_GameSelect>().DeleteGame(gameNumber);
    }

    public int GetNumber()
    {
        return gameNumber;
    }
}
