using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MP_Highlight : MonoBehaviour
{
    MP_GameSelect gameParent;
    MP_GameIcon thisIcon;
    RawImage img;

    // Start is called before the first frame update
    void Start()
    {
        gameParent = FindObjectOfType<MP_GameSelect>();
        thisIcon = GetComponentInParent<MP_GameIcon>();
        img = GetComponent<RawImage>();
    }

    // Update is called once per frame
    void Update()
    {
        if (gameParent.GetCurGame() == thisIcon.GetNumber())
        {
            img.enabled = true;
        }
        else
        {
            img.enabled = false;
        }
    }
}
