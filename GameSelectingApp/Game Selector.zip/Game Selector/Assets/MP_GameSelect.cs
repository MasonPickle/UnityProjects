using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UI;
using System.IO;
using UnityEngine.SceneManagement;

public class MP_GameSelect : MonoBehaviour
{
    //add controller support to game
    [SerializeField]
    GameObject game;
    [SerializeField]
    GameObject[] UIElements;

    List<string> gamePaths = new List<string>();
    GameObject[] games;
    int curGame, UIState;
    float curX, timer, scrollTimer;
    InputField fileInput, imageInput, nameInput;

    // Start is called before the first frame update
    void Start()
    {
        timer = Time.time;
        scrollTimer = Time.time;
        int gameNumber = PlayerPrefs.GetInt("GameNumber", 0);
        Debug.Log(gameNumber);
        games = new GameObject[gameNumber];
        for(int i = 0; i < games.Length; i++)
        {
            games[i] = Instantiate(game, transform);
            //games[i] instead of game
            games[i].GetComponent<MP_GameIcon>().LoadData(i);
        }
        curX = games.Length/2 * 550;
        curGame = 0;
        //localpositions
        transform.localPosition = new Vector3(curX - curGame * 550, 0, 0);

        fileInput = UIElements[1].GetComponentInChildren<InputField>();
        fileInput.onEndEdit.AddListener(delegate { FindPaths(fileInput); });
        imageInput = UIElements[2].GetComponentInChildren<InputField>();
        imageInput.onEndEdit.AddListener(delegate { FindPaths(imageInput); });
        nameInput = UIElements[3].GetComponentInChildren<InputField>();
        nameInput.onEndEdit.AddListener(delegate { AddName(nameInput); });

        SetUIState(0);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetAxis("Horizontal") != 0 && Time.time - scrollTimer - timer > 0.2f)
        {
            curGame += (int)Input.GetAxisRaw("Horizontal");
            ScrollThrough();
            scrollTimer = Time.time;
        }
        if(Input.GetAxis("Mouse ScrollWheel") != 0)
        {
            curGame += (int)Input.GetAxisRaw("Mouse ScrollWheel");
            ScrollThrough();
        }
        if(Input.GetAxisRaw("Submit") == 1 && UIState == 0 && Time.time - timer > 1)
        {
            games[curGame].GetComponent<MP_GameIcon>().RunGame();
            timer = Time.time;
        }
        if (Input.GetKey(KeyCode.Space))
        {
            PlayerPrefs.DeleteAll();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
    void ScrollThrough()
    {
        if (curGame <= -1)
            curGame = games.Length - 1;
        else if (curGame >= games.Length)
            curGame = 0;
        transform.localPosition = new Vector3(curX - curGame * 550, 0, 0);
    }

    public void DeleteGame(int gameIndex)
    {
        Destroy(games[gameIndex].gameObject);
        curGame = 0;
        transform.localPosition = new Vector3(curX + curGame * 550, 0, 0);
        GameObject[] temp = new GameObject[games.Length - 1];
        for(int i = gameIndex; i < games.Length; i++)
        {
            if (i < games.Length - 1)
                games[i] = games[i + 1];
            else
                games[i] = null;
        }
        for (int i = 0; i < games.Length-1; i++)
            temp[i] = games[i];
        Array.Resize(ref games, games.Length - 1);
        for (int i = 0; i < games.Length; i++)
        {
            games[i] = temp[i];
            games[i].GetComponent<MP_GameIcon>().SaveData(i);
        }
        PlayerPrefs.SetInt("GameNumber", games.Length);
    }

    public void SetUIState(int newState)
    {
        if(newState != 0)
        {
            UIElements[4].SetActive(true);
        }
        else
        {
            UIElements[4].SetActive(false);
        }
        UIState = newState;
        for (int i = 0; i < 4; i++)
        {
            if (UIState == i)
                UIElements[i].SetActive(true);
            else
                UIElements[i].SetActive(false);
        }
    }

    public void FindPaths(InputField pathName)
    {
        Debug.Log(pathName.text);
        if (File.Exists(pathName.text))
        {
            Debug.Log("File Exists");
            AddFile(pathName.text);
        }
        else
        {
            SetUIState(UIState - 1);
            Debug.Log(pathName + " is not a valid file");
        }
    }
    public void CancelGame()
    {
        if(UIState > 1)
        {
            DeleteGame(games.Length - 1);
        }
        SetUIState(0);
    }
    void AddFile(string pathName)
    {
        if ((pathName.ToLower().Contains(".exe") || pathName.ToLower().Contains(".bat") || pathName.ToLower().Contains(".jar")) && !gamePaths.Contains(pathName))
        { 
            gamePaths.Add(pathName);
            GameObject[] temp = games;
            for (int i = 0; i < games.Length; i++)
            {
                temp[i] = games[i];
            }
            Array.Resize(ref games, games.Length + 1);
            for(int i = 0; i < games.Length-1; i++)
            {
                games[i] = temp[i];
            } 

            curX = games.Length / 2 * 550;
            transform.localPosition = new Vector3(curX - curGame * 550, 0, 0);

            PlayerPrefs.SetInt("GameNumber", games.Length);

            games[games.Length - 1] = Instantiate(game, transform);
            games[games.Length - 1].GetComponent<MP_GameIcon>().SetPath(pathName);
        }
        else if(pathName.ToLower().Contains(".png")  || pathName.ToLower().Contains(".jpg") || pathName.ToLower().Contains(".jpeg"))
        {
            games[games.Length - 1].GetComponent<MP_GameIcon>().SetImage(pathName);
        }
    }

    public void AddName(InputField iconName)
    {
        games[games.Length - 1].GetComponent<MP_GameIcon>().SetName(iconName.text);
        games[games.Length - 1].GetComponent<MP_GameIcon>().SaveData(games.Length - 1);
    }

    public int GetCurGame()
    {
        return curGame;
    }
}
