using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_PlayerCamera : MonoBehaviour
{
    [SerializeField]
    GameObject[] buttons;
    [SerializeField]
    GameObject camMonitor;

    Quaternion forward, left, right;
    int currentFace = 0;
    bool watchingCameras = false;

    // Start is called before the first frame update
    void Start()
    {
        forward = transform.rotation;
        left = Quaternion.Euler(transform.rotation.x, transform.rotation.y - 45, transform.rotation.z);
        right = Quaternion.Euler(transform.rotation.x, transform.rotation.y + 45, transform.rotation.z);
        camMonitor.SetActive(false);
    }

    public void Turn(int dir)
    {
        currentFace += dir;
        if (currentFace == 2)
            currentFace = 1;
        else if (currentFace == -2)
            currentFace = -1;

        switch (currentFace)
        {
            case -1:
                transform.rotation = left;
                break;
            case 0:
                transform.rotation = forward;
                break;
            case 1:
                transform.rotation = right;
                break;
        }
    }

    public void CamMonitor()
    {
        watchingCameras = !watchingCameras;
        for(int i = 0; i < buttons.Length; i++)
        {
            buttons[i].SetActive(!watchingCameras);
        }
        camMonitor.SetActive(watchingCameras);
    }
}
