using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_CameraController : MonoBehaviour
{
    [SerializeField]
    float speed;
    float startTime;
    MP_Move move;

    // Start is called before the first frame update
    void Start()
    {
        move = FindObjectOfType<MP_Move>();
        startTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        float t = (Time.time - startTime) / speed;

        transform.position = new Vector3(Mathf.SmoothStep(transform.position.x, move.GetSections()[move.GetSectNum()][0].transform.position.x, t), Mathf.SmoothStep(transform.position.y, move.GetSections()[move.GetSectNum()][0].transform.position.y, t), transform.position.z);

        if(RoughCompare(new Vector2(transform.position.x, transform.position.y), new Vector2(move.GetSections()[move.GetSectNum()][0].transform.position.x, move.GetSections()[move.GetSectNum()][0].transform.position.y), 0.5f)){
            startTime = Time.time;
        }
    }

    bool RoughCompare(Vector2 cam, Vector2 target, float spread)
    {
        if (cam.x <= target.x + spread && cam.x >= target.x - spread && cam.y <= target.y + spread && cam.y >= target.y - spread)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
