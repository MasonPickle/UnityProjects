using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Link : MonoBehaviour
{

    int curSection, curPart;
    MP_Move controller;

    // Start is called before the first frame update
    void Start()
    {
        controller = FindObjectOfType<MP_Move>();
    }

    public void SetPart(int sectionNum, int partNum)
    {
        curSection = sectionNum;
        curPart = partNum;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<MP_Obstacle>())
        {
            controller.BreakChain(curSection, curPart);
        }
    }
}
