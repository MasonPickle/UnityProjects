using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MP_ScoreUI : MonoBehaviour
{
    [SerializeField]
    GameObject scoreBack;
    bool finishedLevel = false;
    float timer;
    Text scoreObj;

    // Start is called before the first frame update
    void Start()
    {
        scoreObj = scoreBack.GetComponentInChildren<Text>();
        scoreBack.SetActive(false);
    }

    private void Update()
    {
        if (finishedLevel && Time.time - timer > 3)
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
    }

    public void SetScore(int score)
    {
        scoreObj.text = "Score: " + score;
        scoreBack.SetActive(true);
        timer = Time.time;
        finishedLevel = true;
    }
}
