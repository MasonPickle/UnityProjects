using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Goal : MonoBehaviour
{

    MP_Move move;
    int score = 0;
    MP_ScoreUI scoreObj;

    // Start is called before the first frame update
    void Start()
    {
        move = FindObjectOfType<MP_Move>();
        scoreObj = FindObjectOfType<MP_ScoreUI>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<MP_Link>())
        {
            for(int i = 0; i < move.GetSections().Length; i++)
            {
                for(int x = 0; x < move.GetSections()[i].Length; x++)
                {
                    if(move.GetSections()[i][x] != null)
                    {
                        score++;
                    }
                }
            }
            scoreObj.SetScore(score);
            Destroy(gameObject);
        }
    }
}
