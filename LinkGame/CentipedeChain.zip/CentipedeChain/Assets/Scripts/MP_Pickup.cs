using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Pickup : MonoBehaviour
{

    MP_Move move;

    // Start is called before the first frame update
    void Start()
    {
        move = FindObjectOfType<MP_Move>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.GetComponent<MP_Link>())
        {
            move.AddPart();
            Destroy(gameObject);
        }
    }
}
