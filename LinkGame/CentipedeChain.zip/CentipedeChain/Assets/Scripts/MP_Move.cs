using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;

public class MP_Move : MonoBehaviour
{

    [SerializeField]
    GameObject part;
    [SerializeField]
    Sprite[] partSprites;
    [SerializeField]
    float force = 1;

    //first number is section number, second is parts in the section
    GameObject[][] Sections = new GameObject[5][];
    int sectionNum, curSection, brokenSection;
    bool click = false, chainBroken = false;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Confined;
        for (int i = 0; i < 4; i++)
        {
            Sections[i] = new GameObject[1];
            Sections[i][0] = Instantiate(part);
            Sections[i][0].transform.position = new Vector3(0, 3.36f - (2.2f * i), 0);
            Sections[i][0].GetComponent<SpriteRenderer>().sprite = partSprites[i];
            Sections[i][0].GetComponent<MP_Link>().SetPart(i, 0);
        }
        Sections[3][0].GetComponent<SpringJoint2D>().enabled = false;
        for(int i = 0; i < 3; i++)
        {
            Sections[i][0].GetComponent<SpringJoint2D>().connectedBody =
                    Sections[i + 1][0].GetComponent<Rigidbody2D>();
        }
        Sections[4] = new GameObject[1];
        curSection = 3;
        sectionNum = 0;
        HighlightPart();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W) && Sections[0][0] != null)
        {
            sectionNum = 0;
            HighlightPart();
        }
        if (Input.GetKeyDown(KeyCode.E) && Sections[1][0] != null)
        {
            sectionNum = 1;
            HighlightPart();
        }
        if (Input.GetKeyDown(KeyCode.A) && Sections[2][0] != null)
        {
            sectionNum = 2;
            HighlightPart();
        }
        if (Input.GetKeyDown(KeyCode.S) && Sections[3][0] != null)
        {
            sectionNum = 3;
            HighlightPart();
        }
        if (Input.GetKeyDown(KeyCode.D) && Sections[4][0] != null)
        {
            sectionNum = 4;
            HighlightPart();
        }
        if (Input.GetMouseButton(0))
        {
            click = true;
        }
        else
        {
            click = false;
        }
    }

    private void FixedUpdate()
    {
        if(click)
        {
            for(int i = 0; i < Sections[sectionNum].Length; i++)
            {
                if (Sections[sectionNum][i] != null)
                    Sections[sectionNum][i].GetComponent<Rigidbody2D>().AddForce(
                       (Vector3.right * Input.GetAxis("Mouse X") + Vector3.up * Input.GetAxis("Mouse Y")) * force,
                       ForceMode2D.Impulse);
            }
        }
    }

    void HighlightPart()
    {
        for (int i = 0; i < Sections.Length; i++)
        {
            for(int s = 0; s < Sections[i].Length; s++)
            {
                if(Sections[i][s] != null)
                    Sections[i][s].GetComponent<SpriteRenderer>().color = Color.white;
            }
        }
        for (int i = 0; i < Sections[sectionNum].Length; i++)
            if (Sections[sectionNum][i] != null)
                Sections[sectionNum][i].GetComponent<SpriteRenderer>().color = Color.grey;
    }

    public void AddPart()
    {
        if (chainBroken)
        {
            int unbrokenCount = 0, brokenCount = 0;
            for (int i = 0; i < Sections[0].Length; i++)
            {
                if(brokenSection != 0)
                {
                    if (Sections[brokenSection-1][i] != null)
                    {
                        unbrokenCount++;
                    }
                }
                else
                {
                    unbrokenCount = Sections[0].Length;
                }
                
                if(curSection == 4)
                {
                    if (Sections[curSection][i] != null)
                    {
                        brokenCount++;
                    }
                }
                else
                {
                    if (Sections[curSection + 1][i] != null)
                    {
                        brokenCount++;
                    }
                }
                
            }
            if (unbrokenCount == brokenCount)
            {
                if (curSection == 4)
                {
                    chainBroken = false;
                    int count = 0;
                    for(int i = Sections.Length-1; i >= 0; i--)
                    {
                        int partCount = 0;
                        for(int x = 0; x < Sections[i].Length; x++)
                        {
                            if(Sections[i][x] != null)
                            {
                                partCount++;
                            }
                        }
                        if(partCount > count)
                        {
                            if(i == 4 && partCount == Sections[4].Length)
                            {
                                curSection = 4;
                                break;
                            }
                            else
                                curSection = i;
                        }
                    }
                    Debug.Log("not broke");
                }
                else
                    brokenSection++;
            }
        }
        if (curSection == 4 )
        {
            if (chainBroken)
            {
                curSection = brokenSection;
            }
            else
            {
                GameObject[][] temp = Sections;

                for (int x = 0; x < Sections.Length; x++)
                {
                    temp[x] = Sections[x];
                    for (int i = 0; i < Sections[x].Length; i++)
                    {
                        temp[x][i] = Sections[x][i];
                    }
                }

                for (int i = 0; i < Sections.Length; i++)
                {
                    Array.Resize(ref Sections[i], Sections[i].Length + 1);
                }
                Sections = temp;
                curSection = 0;
            }
        }
        else
        {
            curSection++;
        }

        int tempNum = Sections[curSection].Length - 1;
        if (chainBroken)
        {
            tempNum = 0;
            for (int i = 0; i < Sections[curSection].Length; i++)
                if (Sections[curSection][i] != null)
                {
                    tempNum++;
                }
        }
        
        if (curSection == 0)
        {
            MovePart(Sections[curSection][tempNum - 1].transform, tempNum);

            Sections[curSection][tempNum].GetComponent<SpringJoint2D>().connectedBody =
                    Sections[curSection+1][0].GetComponent<Rigidbody2D>();
            Sections[curSection][tempNum-1].GetComponent<SpringJoint2D>().connectedBody =
                    Sections[curSection][tempNum].GetComponent<Rigidbody2D>();
        }
        else
        {
            if (Sections[curSection].Length < 2)
            {
                int prevNum = Sections[curSection - 1].Length - 1;

                MovePart(Sections[curSection - 1][prevNum].transform, tempNum);
                
                Sections[curSection][0].GetComponent<SpringJoint2D>().enabled = false;
                Sections[curSection - 1][prevNum].GetComponent<SpringJoint2D>().enabled = true;
                Sections[curSection - 1][prevNum].GetComponent<SpringJoint2D>().connectedBody =
                    Sections[curSection][0].GetComponent<Rigidbody2D>();
            }
            else
            {

                if(tempNum < Sections[curSection].Length)
                {
                    if(tempNum == 0)
                    {
                        int prevNum = 0;
                        for (int i = 0; i < Sections[curSection - 1].Length; i++)
                            if (Sections[curSection - 1][i] != null)
                            {
                                prevNum++;
                            }
                        if (prevNum != 0)
                            prevNum--;
                        MovePart(Sections[curSection - 1][prevNum].transform, tempNum);
                    }
                    else if(tempNum == 1)
                    {
                        MovePart(Sections[curSection][0].transform, tempNum);
                    }
                    else
                    {
                        Debug.Log("255");
                        MovePart(Sections[curSection][tempNum - 1].transform, tempNum);
                    }
                }
                else
                {
                    Debug.Log("263");
                    MovePart(Sections[curSection][tempNum - 1].transform, tempNum);
                }

                if (curSection == 4)
                {
                    Sections[curSection][tempNum].GetComponent<SpringJoint2D>().enabled = false;
                }
                else if (Sections[curSection + 1] == null)
                {
                    Sections[curSection][tempNum].GetComponent<SpringJoint2D>().enabled = false;
                }
                else
                {
                    if(Sections[curSection+1][0] == null)
                    {
                        Sections[curSection][tempNum].GetComponent<SpringJoint2D>().enabled = false;
                    }
                    else
                    {
                        Sections[curSection][tempNum - 1].GetComponent<SpringJoint2D>().connectedBody = Sections[curSection][tempNum].GetComponent<Rigidbody2D>();
                        Sections[curSection][tempNum].GetComponent<SpringJoint2D>().connectedBody =
                        Sections[curSection + 1][0].GetComponent<Rigidbody2D>();
                    }
                }

                if(tempNum == 0)
                {
                    int prevNum = 0;
                    for (int i = 0; i < Sections[curSection-1].Length; i++)
                        if (Sections[curSection-1][i] != null)
                        {
                            prevNum++;
                        }
                    if (prevNum != 0)
                        prevNum--;
                    Sections[curSection - 1][prevNum].GetComponent<SpringJoint2D>().enabled = true;
                    Sections[curSection - 1][prevNum].GetComponent<SpringJoint2D>().connectedBody = Sections[curSection][tempNum].GetComponent<Rigidbody2D>();
                }
                else
                {
                    Sections[curSection][tempNum - 1].GetComponent<SpringJoint2D>().enabled = true;
                    Sections[curSection][tempNum - 1].GetComponent<SpringJoint2D>().connectedBody =
                        Sections[curSection][tempNum].GetComponent<Rigidbody2D>();
                }
               
            }
        }
    }
    void MovePart(Transform newParent, int partNum)
    {
        Sections[curSection][partNum] = Instantiate(part, newParent);
        Sections[curSection][partNum].transform.localPosition -= new Vector3(0, 1.2f, 0);
        Sections[curSection][partNum].transform.parent = null;
        Sections[curSection][partNum].GetComponent<SpriteRenderer>().sprite = partSprites[curSection];
        Sections[curSection][partNum].GetComponent<MP_Link>().SetPart(curSection, partNum);
        HighlightPart();
    }

    public void BreakChain(int sectionBreak, int partBreak)
    {
        chainBroken = true;
        brokenSection = sectionBreak;
        if(sectionBreak == 0 && partBreak == 0)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
        }
        else
        {
            if (partBreak == 0)
            {
                int tempNum = 0;
                for (int i = 0; i < Sections[sectionBreak - 1].Length; i++)
                    if (Sections[sectionBreak - 1][i] != null)
                    {
                        tempNum++;
                    }
                tempNum--;
                curSection = brokenSection - 1;

                Sections[sectionBreak - 1][tempNum].GetComponent<SpringJoint2D>().connectedBody = null;
                Sections[sectionBreak - 1][tempNum].GetComponent<SpringJoint2D>().enabled = false;
            }
            else
            {
                curSection = brokenSection;
                Sections[sectionBreak][partBreak - 1].GetComponent<SpringJoint2D>().connectedBody = null;
                Sections[sectionBreak][partBreak - 1].GetComponent<SpringJoint2D>().enabled = false;
            }

            for (int i = partBreak; i < Sections[sectionBreak].Length; i++)
            {
                if(Sections[sectionBreak][i] != null)
                {
                    Destroy(Sections[sectionBreak][i].GetComponent<SpringJoint2D>());
                    Destroy(Sections[sectionBreak][i].GetComponent<MP_Link>());
                    Sections[sectionBreak][i] = null;
                }
            }
            if (sectionBreak != 4)
            {
                for (int i = sectionBreak + 1; i < 5; i++)
                {
                    for (int p = 0; p < Sections[i].Length; p++)
                    {
                        if (Sections[i][p] != null)
                        {
                            Destroy(Sections[i][p].GetComponent<SpringJoint2D>());
                            Destroy(Sections[i][p].GetComponent<MP_Link>());
                            Sections[i][p] = null;
                        }
                    }
                }
            }
        }
    }

    public GameObject[][] GetSections()
    {
        return Sections;
    }
    public int GetSectNum()
    {
        return sectionNum;
    }
}
