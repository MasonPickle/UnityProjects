using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MP_Button : MonoBehaviour
{
    [SerializeField]
    GameObject target;
    [SerializeField]
    [Tooltip("1: placeholder, 2: SwapObjects")]
    int function;

    RaycastHit hit;
    float dist = 2;
    GameObject player;
    bool canPress = false;
    LayerMask timeMask;

    MP_StartObjs[] startObjs;
    MP_EndObjs[] endObjs;
    bool isStart = true;
    
    // Start is called before the first frame update
    void Start()
    {
        startObjs = FindObjectsOfType<MP_StartObjs>();
        endObjs = FindObjectsOfType<MP_EndObjs>();
        SwapObjects(true);
        timeMask = (1 << 9);
        player = FindObjectOfType<MP_PlayerController>().gameObject;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.E) && canPress)
        {
            switch (function)
            {
                case 1:
                    PlaceHolderFunction();
                    break;
                case 2:
                    SwapObjects(!isStart);
                    break;
            }
        }
    }
    private void FixedUpdate()
    {
        if (Physics.Raycast(transform.position, player.transform.position - transform.position, out hit,
            dist, timeMask) && hit.transform.gameObject == player)
            canPress = true;
        else
            canPress = false;
    }

    void PlaceHolderFunction()
    {
        Debug.Log("hit Button");
    }

    public void SwapObjects(bool trueFalse)
    {
        isStart = trueFalse;
        if (!isStart)
        {
            foreach (MP_StartObjs i in startObjs)
                i.gameObject.SetActive(false);
            foreach (MP_EndObjs i in endObjs)
                i.gameObject.SetActive(true);
        }
        else
        {
            foreach (MP_StartObjs i in startObjs)
                i.gameObject.SetActive(true);
            foreach (MP_EndObjs i in endObjs)
                i.gameObject.SetActive(false);
        }
    }
    
    public bool GetSight()
    {
        return canPress;
    }
}
