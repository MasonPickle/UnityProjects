using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_DontDestroyCamera : MonoBehaviour
{
    private static MP_DontDestroyCamera destroyInstance;

    private void Awake()
    {
        if (destroyInstance == null)
        {
            DontDestroyOnLoad(this);
            destroyInstance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
}
