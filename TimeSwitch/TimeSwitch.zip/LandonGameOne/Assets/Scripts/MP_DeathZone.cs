using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_DeathZone : MonoBehaviour
{
    GameObject player;
    Vector3 startPos;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_PlayerController>().gameObject;
        startPos = player.transform.position;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject == player)
        {
            other.transform.position = startPos;
            other.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }   
    }
}
