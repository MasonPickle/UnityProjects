using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MP_TimeTravel : MonoBehaviour
{
    int curTime = 7;
    Camera cam;
    float timer;
    MP_PlayerController player;
    [SerializeField]
    bool pastChange = true, presChange = true, futChange = true;
    [SerializeField]
    RawImage[] indicators;

    // Start is called before the first frame update
    void Start()
    {
        player = GetComponent<MP_PlayerController>();
        cam = FindObjectOfType<MP_CameraController>().GetComponent<Camera>();
        cam.cullingMask = cam.cullingMask ^ (1 << 6);
        cam.cullingMask = cam.cullingMask ^ (1 << 8);
        Physics.IgnoreLayerCollision(9, 6);
        Physics.IgnoreLayerCollision(9, 8);
        timer = Time.time;
        TimeIndicators();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1) && curTime != 6 && timer < Time.time && pastChange)
            ChangeTime(6);

        if (Input.GetKeyDown(KeyCode.Alpha2) && curTime != 7 && timer < Time.time && presChange)
            ChangeTime(7);

        if (Input.GetKeyDown(KeyCode.Alpha3) && curTime != 8 && timer < Time.time && futChange)
            ChangeTime(8);
    }

    void ChangeTime(int newTime)
    {
        Physics.IgnoreLayerCollision(9, curTime);
        Physics.IgnoreLayerCollision(9, newTime, false);
        cam.cullingMask = cam.cullingMask ^ (1 << curTime);
        cam.cullingMask = cam.cullingMask ^ (1 << newTime);
        curTime = newTime;
        TimeIndicators();
        player.SetMask();
    }

    void TimeIndicators()
    {
        for(int i = 0; i < 3; i++)
        {
            indicators[i].color = Color.black;
        }
        switch (curTime)
        {
            case 6:
                indicators[0].color = Color.white;
                break;
            case 7:
                indicators[1].color = Color.white;
                break;
            case 8:
                indicators[2].color = Color.white;
                break;
        }
    }

    public void CollideChange(int time, bool offOn)
    {
        switch (time)
        {
            case 6:
                pastChange = offOn;
                break;
            case 7:
                presChange = offOn;
                break;
            case 8:
                futChange = offOn;
                break;
        }
    }

    public int GetTime()
    {
        return curTime;
    }
}
