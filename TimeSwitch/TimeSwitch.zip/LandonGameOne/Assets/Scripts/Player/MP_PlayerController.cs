using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_PlayerController : MonoBehaviour
{

    [SerializeField]
    float speed, jumpHeight, dist;
    [SerializeField]
    GameObject dirObj;

    MP_TimeTravel TT;
    LayerMask timeMask;
    Rigidbody rb;
    float moveHoriz, moveVert;
    bool onGround = false, jump = false;
    CapsuleCollider col;
    RaycastHit hit;

    // Start is called before the first frame update
    void Start()
    {
        TT = GetComponent<MP_TimeTravel>();
        SetMask();
        rb = GetComponent<Rigidbody>();
        col = GetComponent<CapsuleCollider>();
    }

    // Update is called once per frame
    void Update()
    {
        moveHoriz = Input.GetAxis("Horizontal");
        moveVert = Input.GetAxis("Vertical");

        if (Input.GetKey(KeyCode.Space) && onGround)
            jump = true;
    }

    private void FixedUpdate()
    {
        if (Physics.SphereCast(transform.position, col.radius * 0.98f, Vector3.down, out hit, dist, timeMask))
            onGround = true;
        else
            onGround = false;

        if (jump)
        {
            rb.AddForce(Vector3.up * jumpHeight, ForceMode.Impulse);
            jump = false;
        }

        Vector3 forward = Vector3.Scale(dirObj.transform.forward, new Vector3(1, 0, 1)).normalized;
        Vector3 movement = (moveVert * forward + moveHoriz * dirObj.transform.right).normalized;

        rb.AddForce(movement * speed, ForceMode.Force);
        if(moveHoriz == 0 && moveVert == 0)
            rb.velocity = Vector3.Scale(rb.velocity, new Vector3(0.9f, 1, 0.9f));
    }

    public void SetMask()
    {
        timeMask = (1 << TT.GetTime());
    }
}
