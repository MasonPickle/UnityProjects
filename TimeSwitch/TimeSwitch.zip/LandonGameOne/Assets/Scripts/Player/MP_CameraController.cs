﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_CameraController : MonoBehaviour
{

    public GameObject dirObj;
    public float turnSpeed;

    Vector3 offset;
    GameObject player;
    float rotX;
    float rotY;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_PlayerController>().gameObject;
        offset = player.transform.position - transform.position;

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        transform.rotation = (transform.rotation * Quaternion.Euler(new Vector3(0, Input.GetAxis("Mouse X") * turnSpeed,
            0)));
        rotX += Input.GetAxis("Mouse Y") * turnSpeed;
        rotX = Mathf.Clamp(rotX, -40f, 40f);

        rotY = transform.eulerAngles.y;
        Quaternion rotation = Quaternion.Euler(-rotX, rotY, 0);

        transform.position = player.transform.position - (rotation * offset);
        transform.LookAt(player.transform.position);

        dirObj.transform.rotation = Quaternion.Euler(new Vector3(0, transform.eulerAngles.y, 0));
    }
}
