using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_CollideCheck : MonoBehaviour
{

    [SerializeField]
    [Tooltip("6 = past, 7 = present, 8 = future")]
    int time;
    int layer;
    GameObject player;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_TimeTravel>().gameObject;
    }

    private void Update()
    {
        transform.position = player.transform.position;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.layer == time)
            player.GetComponent<MP_TimeTravel>().CollideChange(time, false);
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == time)
            player.GetComponent<MP_TimeTravel>().CollideChange(time, true);
    }
}
