using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Controller : MonoBehaviour
{

    [SerializeField]
    float speed = 10, jumpForce = 2, dist = 1, levelSpeed = 2;
    [SerializeField]
    LayerMask groundLayer;

    Rigidbody2D rb;
    [SerializeField]
    bool isGrounded = false;
    float x;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxisRaw("Horizontal");
        Jump();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.gravityScale = -rb.gravityScale;
        }
    }
    private void FixedUpdate()
    {
        CheckIfGrounded();
        Move();
        Debug.Log(rb.velocity);
    }

    private void Move()
    {
        rb.velocity = new Vector2(x * speed, rb.velocity.y);
    }

    void Jump()
    {
        if(rb.gravityScale > 0)
        {
            if (Input.GetAxisRaw("Vertical") == 1 && isGrounded)
                rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
        else
        {
            if (Input.GetAxisRaw("Vertical") == -1 && isGrounded)
                rb.velocity = new Vector2(rb.velocity.x, -jumpForce);
        }
    }
    void CheckIfGrounded()
    {
        Vector2 dir = rb.gravityScale > 0 ? Vector2.down : Vector2.up;

        if (Physics2D.BoxCast(transform.position, transform.localScale * 0.98f, transform.rotation.z,
            dir, dist, groundLayer))
            isGrounded = true; 
        else
            isGrounded = false;
    }
}
