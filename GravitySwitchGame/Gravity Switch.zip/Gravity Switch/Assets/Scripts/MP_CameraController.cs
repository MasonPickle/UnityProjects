using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_CameraController : MonoBehaviour
{

    [SerializeField]
    float startX, endX, camSwitchDur;

    bool follow = false, shifting = false, animating = false;
    GameObject player;
    float offset, initialX, camTime;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_Controller>().gameObject;
        offset = transform.position.y - player.transform.position.y;
        initialX = startX;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetAxis("Horizontal") > 0 && player.transform.position.x > startX
            && player.transform.position.x > initialX)
            startX = player.transform.position.x;

        if (player.transform.position.x >= startX && player.transform.position.x <= endX)
            follow = true;
        else
            follow = false;
    }

    private void LateUpdate()
    {
        if (follow)
            transform.position = new Vector3(player.transform.position.x, transform.position.y, 
                transform.position.z);

        CameraMove();
    }

    void CameraMove()
    {
        //shifting = true means it's reversed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            shifting = !shifting;
            animating = true;
        }

        if (animating)
        {
            if (shifting)
            {
                if (transform.position.y <= player.transform.position.y - offset)
                {
                    animating = false;
                }
            }
            else
            {
                if (transform.position.y >= player.transform.position.y + offset)
                {
                    animating = false;
                }
            }
        }
        else
        {
            if (shifting)
            {
                transform.position = new Vector3(transform.position.x, player.transform.position.y - offset,
                        transform.position.z);
            }
            else
            {
                transform.position = new Vector3(transform.position.x, player.transform.position.y + offset,
                        transform.position.z);
            } 
        }
    }

    public void ResetCam()
    {
        follow = false;
        animating = false;
        shifting = false;
        startX = initialX;
    }
}
