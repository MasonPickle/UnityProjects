using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MP_Obstacle : MonoBehaviour
{

    [SerializeField]
    bool moving = false;
    [SerializeField]
    Vector3 end;
    [SerializeField]
    float speed;

    Vector3 start, playerStart, camStart;
    GameObject player, cam;
    float startTime;
    bool moveToEnd = true;
     
    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<MP_Controller>().gameObject;
        playerStart = player.transform.position;
        cam = FindObjectOfType<Camera>().gameObject;
        camStart = cam.transform.position;
        start = transform.position;
        startTime = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        if (moving)
        {
            float t = (Time.time - startTime) / speed;

            if (moveToEnd)
                transform.position = new Vector3(Mathf.SmoothStep(start.x, end.x, t),
                    Mathf.SmoothStep(start.y, end.y, t), 0);
            else
                transform.position = new Vector3(Mathf.SmoothStep(end.x, start.x, t),
                    Mathf.SmoothStep(end.y, start.y, t), 0);

            if (transform.position == start)
            {
                startTime = Time.time;
                moveToEnd = true;
            }
            else if (transform.position == end)
            {
                startTime = Time.time;
                moveToEnd = false;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject == player)
        {
            player.transform.position = playerStart;
            player.GetComponent<Rigidbody2D>().gravityScale =
                Mathf.Abs(player.GetComponent<Rigidbody2D>().gravityScale);

            cam.GetComponent<MP_CameraController>().ResetCam();
            cam.transform.position = camStart;
        }
    }
}
